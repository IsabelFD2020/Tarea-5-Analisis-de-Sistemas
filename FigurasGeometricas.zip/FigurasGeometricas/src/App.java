
import java.util.Scanner;
import javax.swing.JOptionPane;

public class App {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic hereTrin
        Scanner sc = new Scanner(System.in);
        FactoryFiguras tipoFigura = new FactoryFiguras();
        String op = "", s = "";

        do {
            System.out.println("______MENU_______\n"
                    + "| - Triangulo.    |\n"
                    + "| - Cuadrado.     |\n"
                    + "| - Rectangulo.   |\n"
                    + "| - Circulo.      |\n"
                    + "|_-_Salir.________|");
            op = sc.nextLine();
            switch (op) {
                case "Triangulo":
                    double resultadoT = tipoFigura.obtenerAreaFigura(Figuras.TRIANGULO);
                    System.out.println("El area del triangulo es: " + resultadoT);
                    break;
                case "Cuadrado":
                    double resultadoC = tipoFigura.obtenerAreaFigura(Figuras.CUADRADO);
                    System.out.println("El area del cuadrado es: " + resultadoC);
                    break;
                case "Rectangulo":
                    double resultadoR = tipoFigura.obtenerAreaFigura(Figuras.RECTANGULO);
                    System.out.println("El area del rectangulo es: " + resultadoR);
                    break;
                case "Circulo":
                    double resultadoCi = tipoFigura.obtenerAreaFigura(Figuras.CIRCULO);
                    System.out.println("El area del circulo es: " + resultadoCi);
                    break;
                case "Salir":
                        s = "Salir";
                    break;
                default:
                    System.out.println("¡Ingrese una opcion del menu!");
            }
        } while (!s.equalsIgnoreCase("Salir"));
    }

}
