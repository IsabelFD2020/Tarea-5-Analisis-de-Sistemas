
import java.util.Scanner;


public class Triangulo implements Figura {

    @Override
    public double areaFigura() {
        //Decalaracion y asignaion de variables
        Scanner sc = new Scanner (System.in);
        System.out.println("Ingrese la base del triangulo");
        int b= sc.nextInt();
        System.out.println("Ingrese la altura del triangulo");
        int h= sc.nextInt();
        
        //Operaciones de calculo
        double area = (b*h)/2;
        
        //Metodo de salida
        return area;
       
    }

    
    
}
