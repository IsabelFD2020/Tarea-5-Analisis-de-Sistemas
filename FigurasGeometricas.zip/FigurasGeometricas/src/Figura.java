
public interface Figura {
    public double areaFigura();
}
