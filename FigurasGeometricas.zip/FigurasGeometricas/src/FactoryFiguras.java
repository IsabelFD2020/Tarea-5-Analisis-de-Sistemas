
public class FactoryFiguras {

    public double obtenerAreaFigura(Figuras figuras) {
        switch (figuras) {
            case TRIANGULO:
                Triangulo triangulo = new Triangulo();
                return triangulo.areaFigura();
            case CUADRADO:
                Cuadrado cuadrado = new Cuadrado();
                return cuadrado.areaFigura();
            case RECTANGULO:
                Rectangulo rectangulo = new Rectangulo();
                return rectangulo.areaFigura();
            case CIRCULO:
                Circulo circulo = new Circulo();
                return circulo.areaFigura();
            default:
                throw new AssertionError();
        }
    }
}
