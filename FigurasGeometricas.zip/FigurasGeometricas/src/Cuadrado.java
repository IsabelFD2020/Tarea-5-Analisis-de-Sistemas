
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alcan
 */
public class Cuadrado implements Figura {

    @Override
    public double areaFigura() {
        //Decalaracion y asignaion de variables
        Scanner sc = new Scanner (System.in);
        System.out.println("Ingrese un lado del cuadrado");
        int l = sc.nextInt();
        
        //Operaciones de calculo
        double area = Math.pow(l, 2);
        
        //Metodo de salida
        return area;
    }

    
}
