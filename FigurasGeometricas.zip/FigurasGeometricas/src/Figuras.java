
public enum Figuras {
    TRIANGULO, CUADRADO, RECTANGULO, CIRCULO;
}
