
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Alcan
 */
public class Circulo implements Figura {

    @Override
    public double areaFigura() {
        //Decalaracion y asignaion de variables
        
        Scanner sc = new Scanner (System.in);
        System.out.println("Ingrese el radio del circulo:");
        int r = sc.nextInt();

        //Operaciones de calculo
        double area = Math.PI * Math.pow(r, 2);
        
        //Metodo de salida
        return area;
    }

    
}
